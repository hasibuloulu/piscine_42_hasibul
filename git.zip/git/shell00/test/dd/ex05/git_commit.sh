#!/bin/bash
git log -n5 --format="%H"
