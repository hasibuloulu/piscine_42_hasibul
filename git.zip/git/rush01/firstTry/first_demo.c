#include <unistd.h>

int	check_cords(int row, int col,int matrix[6][6])
{
	int reset_row = row;
	int reset_col = col;
	int inc = 1;
	if(matrix[row - 1][col] == 4)
	{
		while (reset_row < 5)
		{
			matrix[reset_row][col] = inc;
			reset_row++;
			inc++;
		}
		reset_row = row;
		inc = 1;	
	}
	if (matrix[row][col-1] == 4)
	{
		while (reset_col < 5)
                {
                        matrix[row][reset_col] = inc;
                        reset_col++;
                        inc++;
                }
		reset_col = 0;
		inc = 1;
	}
	return (0);
}

int    solve_matrix(int matrix[6][6])
{
        int     row;
        int     col;
        row = 1;
        while (row < 5)
        {
                col = 1;
                while (col < 5)
                {
                        check_cords(row, col, matrix);
                        col++;
                }
                row++;
        }
	return (0);
}

void    ft_putchar(char c)
{
        write(1, &c, 1);
}

void    print_matrix(int matrix[6][6])
{
        int     i;
        int     j;
        i = 1;
        while (i < 5)
        {
                j = 1;
                while (j < 5)
                {
                        ft_putchar(matrix[i][j] +'0');
                        ft_putchar(' ');
                        j++;
                }
                write(1, "\n", 1);
                i++;
        }
}

void    ft_putstr(char *str)
{
        int     i;
        i = 0;
        while (str[i] != 0)
        {
                ft_putchar(str[i]);
                i++;
        }
}

int     main(int argc, char *argv[])
{
        if (argc != 2)
        {
                ft_putstr("error");
                return (1);
        }
        
        int     matrix[6][6] = {
        {0, 4, 3, 2, 1, 0},
        {4, 0, 0, 0, 0, 1},
        {3, 0, 0, 0, 0, 2},
        {2, 0, 0, 0, 0, 2},
        {1, 0, 0, 0, 0, 2},
        {0, 1, 2, 2, 2, 0}};
	solve_matrix(matrix);
	print_matrix(matrix);
}
