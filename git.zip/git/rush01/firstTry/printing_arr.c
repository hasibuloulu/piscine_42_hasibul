#include <unistd.h>

// reference LeeSinLiang git
void	printing_arr(int arr[4][4])
{
	int		i;
	int		j;
	char	ans;

	i = -1;
	while (++i < 4)
	{
		j = -1;
		while (++j < 3)
		{
			ans = arr[i][j] + 48;
			write(1, &ans, 1);
			write(1, " ", 1);
		}
		ans = arr[i][j] + 48;
		write(1, &ans, 1);
		write(1, "\n", 1);
	}
}
int	main()
 {
    // input the array 4*4 
	int arr[4][4] = {{1,2,3,3},
	                 {3,3,1,2},
	                 {1,2,2,2},
	                 {4,3,1,2}};
	// printing array using function printing array
    printing_arr(arr);
  
