/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpierce <mpierce@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/07 18:24:11 by mpierce           #+#    #+#             */
/*   Updated: 2024/07/07 18:57:21 by mpierce          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	main(int argc, char *argv[])
{
	int	is_valid();
	void	ft_putstr();
	int	ft_enter_clues();
	int	solve_matrix();
	void	print_matrix();

	int	matrix[6][6] = {
		{0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0, 0}};
	if (is_valid(argc, argv) == '0')
	{
		ft_putstr("Error");
		return (0);
	}
	ft_enter_clues(argv, matrix);
	solve_matrix(matrix);
	print_matrix(matrix);
	return (0);
}
