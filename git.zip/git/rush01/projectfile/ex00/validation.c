/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validation.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpierce <mpierce@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/06 17:24:18 by mpierce           #+#    #+#             */
/*   Updated: 2024/07/07 18:50:03 by mpierce          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	length;

	length = 0;
	while (str[length] != '\0')
		length++;
	return (length);
}

int	is_valid(int argc, char *argv[])
{
	int	i;
	int	num;
	int	ft_atoi();

	i = 0;
	if (argc != 2)
		return (0);
	if (ft_strlen(argv[1]) != 32)
		return (0);
	while (argv[1][i] != '\0')
	{
		if (argv[1][i] >= '0' && argv[1][i] <= '9')
		{
			num = (ft_atoi(argv[1] + i));
			if (num < 1 || num > 4)
				return (0);
			while (argv[1][i] >= '0' && argv[1][i] <= '9')
				i++;
		}
		else if (argv[1][i] == 32)
			i++;
		else
			return (0);
	}
	return (1);
}
