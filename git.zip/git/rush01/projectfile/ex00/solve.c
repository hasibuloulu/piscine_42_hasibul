/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpierce <mpierce@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/07 16:31:37 by mpierce           #+#    #+#             */
/*   Updated: 2024/07/07 18:49:38 by mpierce          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	check_cords_row(int row, int col, int matrix[6][6])
{
	int	reset_row;
	int	inc;

	reset_row = row;
	if (matrix[row - 1][col] == 4)
	{
		inc = 1;
		while (reset_row < 5)
		{
			matrix[reset_row][col] = inc;
			reset_row++;
			inc++;
		}
	}
	return (0);
}

int	check_cords_col(int row, int col, int matrix[6][6])
{
	int	reset_col;
	int	inc;

	reset_col = col;
	if (matrix[row][col - 1] == 4)
	{
		inc = 1;
		while (reset_col < 5)
		{
			matrix[row][reset_col] = inc;
			reset_col++;
			inc++;
		}
	}
	return (0);
}

int	solve_matrix(int matrix[6][6])
{
	int	row;
	int	col;

	row = 1;
	while (row < 5)
	{
		col = 1;
		while (col < 5)
		{
			check_cords_row(row, col, matrix);
			check_cords_col(row, col, matrix);
			col++;
		}
		row++;
	}
	return (0);
}

void	print_matrix(int matrix[6][6])
{
	int	i;
	int	j;
	void	ft_putchar();

	i = 1;
	while (i < 5)
	{
		j = 1;
		while (j < 5)
		{
			ft_putchar(matrix[i][j] + '0');
			ft_putchar(' ');
			j++;
		}
		write(1, "\n", 1);
		i++;
	}
}

int	ft_enter_clues(char *argv[], int matrix[6][6])
{
	int	clues;
	int	i;
	int	j;
	int	ft_atoi();
	int	ft_assign();

	i = 0;
	j = 1;
	while (argv[1][i] != 0)
	{
		if (argv[1][i] >= '0' && argv[1][i] <= '9')
		{
			clues = ft_atoi(&argv[1][i]);
			ft_assign(matrix, clues, j);
			while (argv[1][i] > '0' && argv[1][i] <= '9')
			{
				i++;
				j++;
			}
		}
		else
			i++;
	}
	return (0);
}
