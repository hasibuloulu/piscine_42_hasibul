/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/14 16:24:28 by muislam           #+#    #+#             */
/*   Updated: 2024/07/14 16:30:08 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char **argv)
{
	int	index;
	int	i;

	i = 1;
	while (i < argc)
	{
		index = 0;
		while (argv[i][index])
		{
			write(1, &argv[i][index], 1);
			index++;
		}
		write(1, "\n", 1);
		i++;
	}
}
