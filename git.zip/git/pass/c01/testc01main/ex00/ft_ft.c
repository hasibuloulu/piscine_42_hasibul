/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/02 11:05:49 by muislam           #+#    #+#             */
/*   Updated: 2024/07/02 12:49:44 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ft(int *nbr)
{	
	*nbr = 42;
}
/*
#include <stdio.h>

int main()
{
	int 	a;
	int 	*ptr;

	ptr = &a;

	ft_ft(ptr);

	printf("%d\n", a);
	printf("%d\n", &a);
	printf("%d\n", ptr);
	printf("%d\n", *ptr);
}
*/
