/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/02 14:50:24 by muislam           #+#    #+#             */
/*   Updated: 2024/07/03 10:24:15 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}

/*
#include<stdio.h>

int	main()
{
	int	*********nbr;
	int 	********nbr1;
	int	*******nbr2;
	int	******nbr3;
	int	*****nbr4;
	int	****nbr5;
	int	***nbr6;
	int	**nbr7;
	int	*nbr8;
	int	n;

	n = 21;
	printf("%d\n", n);
	
	nbr8 = &n;
	nbr7 = &nbr8;
	nbr6 = &nbr7;
	nbr5 = &nbr6;
	nbr4 = &nbr5;
	nbr3 = &nbr4; 
	nbr2 = &nbr3;
	nbr1 = &nbr2;
	nbr  = &nbr1;

	ft_ultimate_ft(nbr);
	printf("%d\n", n);
	return (0);
}
*/	
