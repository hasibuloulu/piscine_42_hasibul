/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/02 15:41:18 by muislam           #+#    #+#             */
/*   Updated: 2024/07/03 10:29:24 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_swap(int *a, int *b)
{
	int	tmp;

	tmp = *a;
	*a = *b;
	*b = tmp;
}
/*
#include<stdio.h>

int	main()
{
	int A, B, *ptrA, *ptrB;

	A = 1;
	B = 2;

	ptrA = &A;
	ptrB = &B;

	ft_swap(ptrA, ptrB);

	printf("A: %d, B: %d\n", A, B);
}
*/
