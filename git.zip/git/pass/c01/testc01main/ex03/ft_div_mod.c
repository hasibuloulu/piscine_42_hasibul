/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/02 16:26:22 by muislam           #+#    #+#             */
/*   Updated: 2024/07/03 10:46:19 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}

/*
#include<stdio.h>

int main(void)
{
	int c, d, div, mod;
	
	c = 43;
	d = 5;
	ft_div_mod(c, d, &div, &mod);
	printf (" c: %d d: %d div: %d mod: %d", c, d, div, mod);
}
*/
