/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/07 14:15:20 by muislam           #+#    #+#             */
/*   Updated: 2024/07/09 11:37:29 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	p;

	p = 0;
	while (s1[p] != '\0' && s2[p] != '\0' && p < n)
	{
		if (s1[p] != s2[p])
			return (s1[p] - s2[p]);
		++p;
	}
	if (p != n)
		return (s1[p] - s2[p]);
	return (0);
}
/*
#include <stdio.h>

int main()
{
	printf("%d",ft_strncmp("hello", "helloHIVER",8));
}
*/
