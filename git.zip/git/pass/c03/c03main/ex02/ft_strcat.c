/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/07 14:57:29 by muislam           #+#    #+#             */
/*   Updated: 2024/07/09 11:46:09 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	int	p;
	int	q;

	p = 0;
	q = 0;
	while (dest[p] != '\0')
	{
		p++;
	}
	while (src[q] != '\0')
	{
		dest[p + q] = src[q];
		q++;
	}
	dest[p + q] = '\0';
	return (dest);
}
/*
#include<stdio.h>
#include <string.h>

int main()
{
	char x[] = "hello";
	char y[] = "there";

   	char s[] = "hello";
	char r[] = "there";
	
	printf("%s\n", ft_strcat(x,y));

	printf("%s", strcat(s,r));
}
*/
