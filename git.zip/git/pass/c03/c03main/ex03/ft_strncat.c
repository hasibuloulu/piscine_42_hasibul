/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/07 14:58:47 by muislam           #+#    #+#             */
/*   Updated: 2024/07/09 11:49:06 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	p;
	unsigned int	q;

	p = 0;
	q = 0;
	while (dest[p] != '\0')
		p++;
	while (src[q] != '\0' && q < nb)
	{
		dest[p] = src [q];
		p++;
		q++;
	}
	dest[p] = '\0';
	return (dest);
}
/*
#include <stdio.h>

int main ()
{
	char x[20] = "1454";
	char y[20] = "4999";
	//char *t = ft_strncat(x, y, 5);
	printf("%s\n", ft_strncat(x, y, 20));
}
*/
