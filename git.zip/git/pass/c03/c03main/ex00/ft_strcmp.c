/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/07 14:40:10 by muislam           #+#    #+#             */
/*   Updated: 2024/07/09 11:33:35 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	int	p;

	p = 0;
	while (s1[p] == s2[p] && s1[p] != '\0' && s2[p] != '\n')
		p++;
	return (s1[p] - s2[p]);
}
/*
#include <stdio.h>

int main()
{
	printf("%d", ft_strcmp("Hello", "Hello1"));
	printf("\n%d", ft_strcmp("Hello", "He"));
	printf("\n%d", ft_strcmp("He", "Hello"));
	printf("\n%d", ft_strcmp("Hello", "Hello"));
}
*/
/*
int main ()
{
char *str1 = "hi hiver";
char *str2 = "HI HIVER";

printf ("output: %d", ft_strcmp(str1, str2));
}
*/
