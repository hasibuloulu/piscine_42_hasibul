/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/07 14:59:25 by muislam           #+#    #+#             */
/*   Updated: 2024/07/09 16:49:39 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	int	p;
	int	q;

	p = 0;
	while (*to_find == '\0')
		return (str);
	while (str[p] != '\0')
	{
		q = 0;
		while (str[p + q] == to_find [q])
		{
			q++;
			if (to_find[q] == '\0')
				return (&str[p]);
		}
		p++;
	}
	return (0);
}
