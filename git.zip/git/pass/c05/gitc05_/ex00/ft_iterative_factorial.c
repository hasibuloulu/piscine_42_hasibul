/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/09 18:37:12 by muislam           #+#    #+#             */
/*   Updated: 2024/07/10 14:06:42 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	fac_value;
	int	p;

	fac_value = 1;
	p = 1;
	if ((nb < 0) || (nb > 12))
		return (0);
	if (nb == 0 || nb == 1)
		return (1);
	while (p <= nb)
	{
		fac_value = p * fac_value;
		p++;
	}
	return (fac_value);
}
