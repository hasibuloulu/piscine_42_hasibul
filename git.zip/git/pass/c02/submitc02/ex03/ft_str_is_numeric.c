/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 17:26:14 by muislam           #+#    #+#             */
/*   Updated: 2024/07/03 20:34:20 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_numeric(char *str)
{
	int	p;

	p = 0;
	while (str[p] != '\0')
	{
		if ((str[p] >= '0') && (str[p] <= '9'))
			p++;
		else
			return (0);
	}
	return (1);
}
/*
int	main(void)
{
	int	number;
	char	input[] = "132324";
	number = ft_str_is_numeric(input);
	printf("%d\n", number);
}
*/
