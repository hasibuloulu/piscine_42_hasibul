/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 20:01:28 by muislam           #+#    #+#             */
/*   Updated: 2024/07/03 20:50:34 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strlowcase(char *str)
{
	int	p;

	p = 0;
	while (str[p] != '\0')
	{
		if (str[p] >= 'A' && str[p] <= 'Z')
			str[p] = str[p] + 32;
		p++;
	}
	return (str);
}
/*
int main(void)
{
        char    input[] = "AAKKGFYKLO";
        printf("%s\n", ft_strlowcase(input));
}
*/
