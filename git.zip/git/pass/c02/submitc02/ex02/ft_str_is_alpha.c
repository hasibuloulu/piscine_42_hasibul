/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 16:21:48 by muislam           #+#    #+#             */
/*   Updated: 2024/07/03 21:19:34 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str)
{
	int	p;

	p = 0;
	while (str[p] != '\0')
	{
		if ((str[p] >= 'A' && str[p] <= 'Z')
			|| (str[p] >= 'a' && str[p] <= 'z'))
			p++;
		else
			return (0);
	}
	return (1);
}
/*
#include <stdio.h>

int	main(void)
{
	int alphabet;
	char input[] = "dfddgfgtht";
	alphabet = ft_str_is_alpha(input);
	printf("%d\n", alphabet);
}
*/
