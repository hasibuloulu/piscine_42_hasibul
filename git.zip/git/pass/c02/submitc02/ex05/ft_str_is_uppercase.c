/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 17:33:51 by muislam           #+#    #+#             */
/*   Updated: 2024/07/03 20:39:40 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_uppercase(char *str)
{
	int	p;

	p = 0;
	while (str[p] != '\0')
	{
		if ((str[p] >= 'A') && (str[p] <= 'Z'))
			p++;
		else
			return (0);
	}
	return (1);
}
/*
int     main(void)
{
        int     uppercase;
        char    input[] = "AAAA";
        uppercase  = ft_str_is_uppercase(input);
        printf("%d\n", uppercase);
}
*/
