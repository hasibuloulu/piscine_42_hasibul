/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 19:49:08 by muislam           #+#    #+#             */
/*   Updated: 2024/07/03 20:43:57 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strupcase(char *str)
{
	int	p;

	p = 0;
	while (str[p] != '\0')
	{
		if (str[p] >= 'a' && str[p] <= 'z')
			str[p] = str[p] - 32;
		p++;
	}
	return (str);
}
/*
int main(void)
{
        char    input[] = "adsadsd";
        printf("%s\n", ft_strupcase(input));
}
*/
