/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 19:19:35 by muislam           #+#    #+#             */
/*   Updated: 2024/07/03 19:31:33 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str)
{
	int	p;

	p = 0;
	while (str[p] != '\0')
	{
		if ((str[p] >= 32 && str[p] <= 126))
			p++;
		else
			return (0);
	}
	return (1);
}
/*
int main(void)
{
	int	print_alphabet;
	char	input[] = "µ";
	print_alphabet = ft_str_is_printable (input);
	printf("%d\n", print_alphabet);
}
*/
