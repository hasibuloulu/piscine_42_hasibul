/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 17:27:59 by muislam           #+#    #+#             */
/*   Updated: 2024/07/03 20:35:48 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str)
{
	int	p;

	p = 0;
	while (str[p] != '\0')
	{
		if ((str[p] >= 'a') && (str[p] <= 'z'))
			p++;
		else
			return (0);
	}
	return (1);
}
/*
#include <stdio.h>

int	main(void)
{
	int	lowercase;
	char	input[] = "abfgf";
	lowercase  = ft_str_is_lowercase(input);
	printf("%d\n", lowercase);
}
*/
