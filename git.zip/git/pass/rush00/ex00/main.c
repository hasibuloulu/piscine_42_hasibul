void	rush(int size_x, int size_y);

int	main(void)
{
	rush(1, 1);
	return (0);
}
