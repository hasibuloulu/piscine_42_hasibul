void ft_putchar(char c);

void rush (int x, int y);
{
	ft_putchar('\n');
}
