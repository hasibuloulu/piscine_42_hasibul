/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rplata <rplata@student.hive.fi>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/30 08:37:16 by rplata            #+#    #+#             */
/*   Updated: 2024/06/30 14:30:06 by rplata           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char a);

void	functionn(int n, char b)
{
	while (n > 0)
	{
		ft_putchar(b);
		n--;
	}
}

void	functionfr(int x, int y)
{
	if (x == 1 && y > 0)
	{
		ft_putchar('A');
	}
	if (x > 1 && y > 0)
	{
		ft_putchar('A');
		if (x >= 3)
		{
			functionn((x - 2), 'B');
		}
		ft_putchar('C');
	}
}

void	functionb(int x, int y)
{
	int	a;

	a = 0;
	while ((x == 1 && y > 2 && x > 0) && (a < (y - 2)))
	{
		ft_putchar('\n');
		ft_putchar('B');
		a++;
	}
	while ((y != 2 && y > 1 && x != 1 && x > 0) && (a < (x + 2)))
	{
		ft_putchar('\n');
		ft_putchar('B');
		functionn((x - 2), ' ');
		ft_putchar('B');
		if (y > 1)
		{
			y--;
		}
		a++;
	}
}

void	functionlr(int x, int y)
{
	if (x == 1 && y > 0 && y != 1)
	{
		ft_putchar('\n');
		ft_putchar('C');
	}
	if (x > 1 && y > 1)
	{
		ft_putchar('\n');
		ft_putchar('C');
		if (x >= 2)
		{
			functionn((x - 2), 'B');
			ft_putchar('A');
		}
	}
}

void	rush(int x, int y)
{
	functionfr(x, y);
	functionb(x, y);
	functionlr(x, y);
	ft_putchar('\n');
}
