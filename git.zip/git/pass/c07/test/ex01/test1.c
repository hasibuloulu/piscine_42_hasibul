#include <stdio.h>
#include <stdlib.h>

int *ft_range(int min, int max)
{
    int *tab;
    int j;
    
    j = 0;
    
    if (min >= max)
        return (0);
    tab = (int *) malloc((max - min) * sizeof(int));
    if (tab == NULL)
    {
        return (NULL);
    }
    while (min < max)
    {
        tab[j]= min;
        min++;
        j++;
    }
    return tab;
}
/*
int main() {
    int maximum = 16;
    int minimum = -3;
    
    int *arr = ft_range(minimum, maximum);
    for(int i = 0; i < maximum - minimum  ; i++)
    {
        printf("%d\n",arr[i]);
    }
    
    return 0;
}
*/

/*#include<stdio.h>
int main()
{
	int *tab;
	int i = 0;
	tab = ft_range(-3, 5);
	while(i < 8)
	{
		printf("%d ", tab[i]);
		i++;
	}
}
*/
