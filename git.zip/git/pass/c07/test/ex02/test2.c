#include <stdlib.h>
#include <stdio.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	i;
	int	*result;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	i = max - min;
	result = malloc(sizeof(int) * (i));
	if (result == NULL)
	{
		*range = NULL;
		return (-1);
	}
	*range = result;
	i = 0;
	while (max > min)
	{
		result[i] = min;
		min++;
		i++;
	}
	return (i);
}
/*
int main(void)
{
	int	i = 0;
	int	min = 5;
	int	max = 10;
	int	*tab;
	int	size;
	
	size = ft_ultimate_range(&tab, min, max);
	while(i < size)
	{
		printf("%d, ", tab[i]);
		i++;
	}
}
*/

/*
#include<stdio.h>
int main()
{
	int return_value;
	int *range;
	int i = 0;
	return_value = ft_ultimate_range(&range, -1, 7);
	printf("%d\n", return_value);
	while(i < 8)
	{
		printf("%d ", range[i]);
		i++;
	}
}
*/

