int	main()
{
	char	*str;
	char *argv[5] = {"Hello", "to", "the", "swimmer", "42"};
	str = ft_strjoin(5, argv, "--");
	printf("%s\n", str);
	return (0);
}
