/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/14 18:42:38 by muislam           #+#    #+#             */
/*   Updated: 2024/07/14 19:07:07 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*range;
	int	j;

	j = 0;
	if (min >= max)
		return (0);
	range = (int *) malloc((max - min) * sizeof(int));
	if (range == NULL)
	{
		return (NULL);
	}
	while (min < max)
	{
		range[j] = min;
		min++;
		j++;
	}
	return (range);
}
