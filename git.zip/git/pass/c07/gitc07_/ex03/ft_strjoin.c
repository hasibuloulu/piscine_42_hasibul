/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: muislam <muislam@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/15 15:50:06 by muislam           #+#    #+#             */
/*   Updated: 2024/07/16 11:46:06 by muislam          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	p;

	p = 0;
	while (str[p])
	{
		p++;
	}
	return (p);
}

char	*ft_strcat(char *dest, char *src)
{
	int	p;
	int	q;

	p = 0;
	q = 0;
	while (dest[p] != '\0')
	{
		p++;
	}
	while (src[q] != '\0')
	{
		dest[p + q] = src[q];
		q++;
	}
	dest[p + q] = '\0';
	return (dest);
}

int	cal_len(int size, char **strs, char *sep)
{
	int	i;
	int	len;

	len = 0;
	i = 0;
	while (i < size)
	{
		len += ft_strlen(strs[i]);
		i++;
	}
	len = len + ft_strlen(sep) * (size - 1);
	return (len);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*ptr;
	int		i;
	int		len;

	i = 0;
	if (size == 0)
	{
		ptr = (char *)malloc(sizeof(char));
		*ptr = '\0';
		return (ptr);
	}
	len = cal_len(size, strs, sep);
	ptr = (char *)malloc((len + 1) * sizeof(char));
	i = 0;
	ptr[0] = 0;
	while (i < size)
	{
		ft_strcat(ptr, strs[i]);
		if (i < size - 1)
			ft_strcat(ptr, sep);
		i++;
	}
	ptr[len] = '\0';
	return (ptr);
}
