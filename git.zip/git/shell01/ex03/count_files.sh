#!/bin/sh
find . | wc -l | sed 's/ //g'
