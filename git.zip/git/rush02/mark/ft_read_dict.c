/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_read_dict.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mcampita <mcampita@student.hive.fi>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/13 15:28:33 by mcampita          #+#    #+#             */
/*   Updated: 2024/07/13 19:24:46 by mcampita         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

int main(){
    
    char *fileName = "numbers.dict";

    int fd = open(fileName, O_RDWR);
    
    if(fd == -1){
        printf("\nError Opening File!\n");
        exit(1);
    }
    //else{
        //printf("\nFile %s opened sucessfully!\n", fileName);
    //}

    char buffer[1024];
    char *ptr;
    char str[50];
    int count = 0;

    ptr = read(fd, buffer, sizeof(buffer));

    int bytesRead = read(fd, buffer, sizeof(buffer));

    //printf("%d bytes\n", bytesRead);
    printf("%s\n", buffer);
    //while(bytesRead != 0)
    //{
    //printf("%s", buffer);
    //bytesRead++;
    //}
    //test

    close(fd);

    return 0;
}
