#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>

void pull_from_dict(char digit, int len);

bool is_digit(char c)
{
    return (c >= '0' && c <= '9');
}

bool check_if_suitable_num(char *str)
{
    int i;
    
    i = 0;
    while(str[i] != '\0')
    {
        if(is_digit(str[i] == false))
            return false;
    }
    return true;
}

int get_str_len(char *str)
{
    int i;

    i = 0;
    while(str[i] != '\0')
    {
        i += 1;
    }
    return i;
}

void my_atoi(char *str)
{
    if(check_if_suitable_num(str) == true)
    {
        int i;
        char digit;
        int len;

        i = 0;
        len = get_str_len(str);
        while(str[i] != '\0')
        {
            digit = str[i];
            pull_from_dict(digit, len - 1);
            i += 1;
        }
    }
    else
    {
        write(1, "Error\n", 5);
    }
}

int main(int nargs, char **vargs)
{
    char *input = vargs[1];
    my_atoi(input);
}